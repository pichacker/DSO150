﻿namespace DSO150_Scope_View
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.portToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnPort = new System.Windows.Forms.Button();
            this.btnProcess = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSampleInterval = new System.Windows.Forms.Label();
            this.lblDuty = new System.Windows.Forms.Label();
            this.lblVrms = new System.Windows.Forms.Label();
            this.lblVpp = new System.Windows.Forms.Label();
            this.lblVAvr = new System.Windows.Forms.Label();
            this.lblVMin = new System.Windows.Forms.Label();
            this.lblVMax = new System.Windows.Forms.Label();
            this.lblPW = new System.Windows.Forms.Label();
            this.lblCycle = new System.Windows.Forms.Label();
            this.lblFrequency = new System.Windows.Forms.Label();
            this.lblRecordLength = new System.Windows.Forms.Label();
            this.lblTriggerLevel = new System.Windows.Forms.Label();
            this.lblTriggerSlope = new System.Windows.Forms.Label();
            this.lblTriggerMode = new System.Windows.Forms.Label();
            this.lblHPos = new System.Windows.Forms.Label();
            this.lblTimebase = new System.Windows.Forms.Label();
            this.lblVPos = new System.Windows.Forms.Label();
            this.lblCouple = new System.Windows.Forms.Label();
            this.lblVSen = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTBase = new System.Windows.Forms.Label();
            this.lblEnd = new System.Windows.Forms.Label();
            this.lblStart = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnShiftRight = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnShiftLeft = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnZoomPlus = new System.Windows.Forms.Button();
            this.btnZoomMinus = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.ReadBufferSize = 8192;
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 732);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1124, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.portToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1124, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "&File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.loadToolStripMenuItem.Text = "&Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.saveToolStripMenuItem.Text = "&Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // portToolStripMenuItem
            // 
            this.portToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.settingToolStripMenuItem});
            this.portToolStripMenuItem.Name = "portToolStripMenuItem";
            this.portToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.portToolStripMenuItem.Text = "&Port";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.settingToolStripMenuItem.Text = "&Setting";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // btnPort
            // 
            this.btnPort.Location = new System.Drawing.Point(10, 42);
            this.btnPort.Margin = new System.Windows.Forms.Padding(2);
            this.btnPort.Name = "btnPort";
            this.btnPort.Size = new System.Drawing.Size(69, 24);
            this.btnPort.TabIndex = 8;
            this.btnPort.Text = "Open Port";
            this.btnPort.UseVisualStyleBackColor = true;
            this.btnPort.Click += new System.EventHandler(this.btnPort_Click);
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(10, 78);
            this.btnProcess.Margin = new System.Windows.Forms.Padding(2);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(69, 24);
            this.btnProcess.TabIndex = 9;
            this.btnProcess.Text = "Plot Data";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblSampleInterval);
            this.groupBox1.Controls.Add(this.lblDuty);
            this.groupBox1.Controls.Add(this.lblVrms);
            this.groupBox1.Controls.Add(this.lblVpp);
            this.groupBox1.Controls.Add(this.lblVAvr);
            this.groupBox1.Controls.Add(this.lblVMin);
            this.groupBox1.Controls.Add(this.lblVMax);
            this.groupBox1.Controls.Add(this.lblPW);
            this.groupBox1.Controls.Add(this.lblCycle);
            this.groupBox1.Controls.Add(this.lblFrequency);
            this.groupBox1.Controls.Add(this.lblRecordLength);
            this.groupBox1.Location = new System.Drawing.Point(404, 25);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(404, 92);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sample Statistics";
            // 
            // lblSampleInterval
            // 
            this.lblSampleInterval.AutoSize = true;
            this.lblSampleInterval.Location = new System.Drawing.Point(136, 37);
            this.lblSampleInterval.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSampleInterval.Name = "lblSampleInterval";
            this.lblSampleInterval.Size = new System.Drawing.Size(80, 13);
            this.lblSampleInterval.TabIndex = 18;
            this.lblSampleInterval.Text = "Sample Interval";
            // 
            // lblDuty
            // 
            this.lblDuty.AutoSize = true;
            this.lblDuty.Location = new System.Drawing.Point(4, 64);
            this.lblDuty.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDuty.Name = "lblDuty";
            this.lblDuty.Size = new System.Drawing.Size(29, 13);
            this.lblDuty.TabIndex = 17;
            this.lblDuty.Text = "Duty";
            // 
            // lblVrms
            // 
            this.lblVrms.AutoSize = true;
            this.lblVrms.Location = new System.Drawing.Point(289, 50);
            this.lblVrms.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVrms.Name = "lblVrms";
            this.lblVrms.Size = new System.Drawing.Size(30, 13);
            this.lblVrms.TabIndex = 13;
            this.lblVrms.Text = "Vrms";
            // 
            // lblVpp
            // 
            this.lblVpp.AutoSize = true;
            this.lblVpp.Location = new System.Drawing.Point(289, 23);
            this.lblVpp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVpp.Name = "lblVpp";
            this.lblVpp.Size = new System.Drawing.Size(26, 13);
            this.lblVpp.TabIndex = 12;
            this.lblVpp.Text = "Vpp";
            // 
            // lblVAvr
            // 
            this.lblVAvr.AutoSize = true;
            this.lblVAvr.Location = new System.Drawing.Point(289, 37);
            this.lblVAvr.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVAvr.Name = "lblVAvr";
            this.lblVAvr.Size = new System.Drawing.Size(29, 13);
            this.lblVAvr.TabIndex = 11;
            this.lblVAvr.Text = "Vavr";
            // 
            // lblVMin
            // 
            this.lblVMin.AutoSize = true;
            this.lblVMin.Location = new System.Drawing.Point(136, 64);
            this.lblVMin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVMin.Name = "lblVMin";
            this.lblVMin.Size = new System.Drawing.Size(30, 13);
            this.lblVMin.TabIndex = 10;
            this.lblVMin.Text = "Vmin";
            // 
            // lblVMax
            // 
            this.lblVMax.AutoSize = true;
            this.lblVMax.Location = new System.Drawing.Point(136, 50);
            this.lblVMax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVMax.Name = "lblVMax";
            this.lblVMax.Size = new System.Drawing.Size(33, 13);
            this.lblVMax.TabIndex = 9;
            this.lblVMax.Text = "Vmax";
            // 
            // lblPW
            // 
            this.lblPW.AutoSize = true;
            this.lblPW.Location = new System.Drawing.Point(4, 50);
            this.lblPW.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPW.Name = "lblPW";
            this.lblPW.Size = new System.Drawing.Size(25, 13);
            this.lblPW.TabIndex = 16;
            this.lblPW.Text = "PW";
            // 
            // lblCycle
            // 
            this.lblCycle.AutoSize = true;
            this.lblCycle.Location = new System.Drawing.Point(4, 37);
            this.lblCycle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCycle.Name = "lblCycle";
            this.lblCycle.Size = new System.Drawing.Size(33, 13);
            this.lblCycle.TabIndex = 15;
            this.lblCycle.Text = "Cycle";
            // 
            // lblFrequency
            // 
            this.lblFrequency.AutoSize = true;
            this.lblFrequency.Location = new System.Drawing.Point(4, 23);
            this.lblFrequency.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFrequency.Name = "lblFrequency";
            this.lblFrequency.Size = new System.Drawing.Size(57, 13);
            this.lblFrequency.TabIndex = 14;
            this.lblFrequency.Text = "Frequency";
            // 
            // lblRecordLength
            // 
            this.lblRecordLength.AutoSize = true;
            this.lblRecordLength.Location = new System.Drawing.Point(136, 23);
            this.lblRecordLength.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRecordLength.Name = "lblRecordLength";
            this.lblRecordLength.Size = new System.Drawing.Size(78, 13);
            this.lblRecordLength.TabIndex = 8;
            this.lblRecordLength.Text = "Record Length";
            // 
            // lblTriggerLevel
            // 
            this.lblTriggerLevel.AutoSize = true;
            this.lblTriggerLevel.Location = new System.Drawing.Point(5, 50);
            this.lblTriggerLevel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTriggerLevel.Name = "lblTriggerLevel";
            this.lblTriggerLevel.Size = new System.Drawing.Size(69, 13);
            this.lblTriggerLevel.TabIndex = 7;
            this.lblTriggerLevel.Text = "Trigger Level";
            // 
            // lblTriggerSlope
            // 
            this.lblTriggerSlope.AutoSize = true;
            this.lblTriggerSlope.Location = new System.Drawing.Point(5, 64);
            this.lblTriggerSlope.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTriggerSlope.Name = "lblTriggerSlope";
            this.lblTriggerSlope.Size = new System.Drawing.Size(70, 13);
            this.lblTriggerSlope.TabIndex = 6;
            this.lblTriggerSlope.Text = "Trigger Slope";
            // 
            // lblTriggerMode
            // 
            this.lblTriggerMode.AutoSize = true;
            this.lblTriggerMode.Location = new System.Drawing.Point(4, 37);
            this.lblTriggerMode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTriggerMode.Name = "lblTriggerMode";
            this.lblTriggerMode.Size = new System.Drawing.Size(70, 13);
            this.lblTriggerMode.TabIndex = 5;
            this.lblTriggerMode.Text = "Trigger Mode";
            // 
            // lblHPos
            // 
            this.lblHPos.AutoSize = true;
            this.lblHPos.Location = new System.Drawing.Point(4, 64);
            this.lblHPos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHPos.Name = "lblHPos";
            this.lblHPos.Size = new System.Drawing.Size(32, 13);
            this.lblHPos.TabIndex = 4;
            this.lblHPos.Text = "Hpos";
            // 
            // lblTimebase
            // 
            this.lblTimebase.AutoSize = true;
            this.lblTimebase.Location = new System.Drawing.Point(4, 23);
            this.lblTimebase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimebase.Name = "lblTimebase";
            this.lblTimebase.Size = new System.Drawing.Size(53, 13);
            this.lblTimebase.TabIndex = 3;
            this.lblTimebase.Text = "Timebase";
            // 
            // lblVPos
            // 
            this.lblVPos.AutoSize = true;
            this.lblVPos.Location = new System.Drawing.Point(4, 50);
            this.lblVPos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVPos.Name = "lblVPos";
            this.lblVPos.Size = new System.Drawing.Size(31, 13);
            this.lblVPos.TabIndex = 2;
            this.lblVPos.Text = "Vpos";
            // 
            // lblCouple
            // 
            this.lblCouple.AutoSize = true;
            this.lblCouple.Location = new System.Drawing.Point(4, 23);
            this.lblCouple.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCouple.Name = "lblCouple";
            this.lblCouple.Size = new System.Drawing.Size(40, 13);
            this.lblCouple.TabIndex = 1;
            this.lblCouple.Text = "Couple";
            // 
            // lblVSen
            // 
            this.lblVSen.AutoSize = true;
            this.lblVSen.Location = new System.Drawing.Point(4, 37);
            this.lblVSen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVSen.Name = "lblVSen";
            this.lblVSen.Size = new System.Drawing.Size(31, 13);
            this.lblVSen.TabIndex = 0;
            this.lblVSen.Text = "Vsen";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblTimebase);
            this.groupBox2.Controls.Add(this.lblTriggerMode);
            this.groupBox2.Controls.Add(this.lblTriggerLevel);
            this.groupBox2.Controls.Add(this.lblTriggerSlope);
            this.groupBox2.Location = new System.Drawing.Point(230, 25);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(170, 92);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sweep";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblCouple);
            this.groupBox3.Controls.Add(this.lblVSen);
            this.groupBox3.Controls.Add(this.lblVPos);
            this.groupBox3.Controls.Add(this.lblHPos);
            this.groupBox3.Location = new System.Drawing.Point(83, 25);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(142, 92);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Input";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.DarkGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblTBase);
            this.panel1.Controls.Add(this.lblEnd);
            this.panel1.Controls.Add(this.lblStart);
            this.panel1.Location = new System.Drawing.Point(10, 121);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1106, 609);
            this.panel1.TabIndex = 13;
            // 
            // lblTBase
            // 
            this.lblTBase.AutoSize = true;
            this.lblTBase.ForeColor = System.Drawing.Color.White;
            this.lblTBase.Location = new System.Drawing.Point(3, 9);
            this.lblTBase.Name = "lblTBase";
            this.lblTBase.Size = new System.Drawing.Size(45, 13);
            this.lblTBase.TabIndex = 2;
            this.lblTBase.Text = "--ms/div";
            // 
            // lblEnd
            // 
            this.lblEnd.AutoSize = true;
            this.lblEnd.ForeColor = System.Drawing.Color.White;
            this.lblEnd.Location = new System.Drawing.Point(1054, 588);
            this.lblEnd.Name = "lblEnd";
            this.lblEnd.Size = new System.Drawing.Size(36, 13);
            this.lblEnd.TabIndex = 1;
            this.lblEnd.Text = "lblEnd";
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.ForeColor = System.Drawing.Color.White;
            this.lblStart.Location = new System.Drawing.Point(15, 588);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(39, 13);
            this.lblStart.TabIndex = 0;
            this.lblStart.Text = "lblStart";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnShiftRight);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.btnShiftLeft);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.btnZoomPlus);
            this.groupBox4.Controls.Add(this.btnZoomMinus);
            this.groupBox4.Location = new System.Drawing.Point(811, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(301, 92);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Controls";
            // 
            // btnShiftRight
            // 
            this.btnShiftRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShiftRight.Location = new System.Drawing.Point(79, 53);
            this.btnShiftRight.Name = "btnShiftRight";
            this.btnShiftRight.Size = new System.Drawing.Size(23, 24);
            this.btnShiftRight.TabIndex = 6;
            this.btnShiftRight.Text = ">";
            this.btnShiftRight.UseVisualStyleBackColor = true;
            this.btnShiftRight.Click += new System.EventHandler(this.btnShiftRight_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "X Pos";
            // 
            // btnShiftLeft
            // 
            this.btnShiftLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShiftLeft.Location = new System.Drawing.Point(6, 53);
            this.btnShiftLeft.Name = "btnShiftLeft";
            this.btnShiftLeft.Size = new System.Drawing.Size(23, 24);
            this.btnShiftLeft.TabIndex = 4;
            this.btnShiftLeft.Text = "<";
            this.btnShiftLeft.UseVisualStyleBackColor = true;
            this.btnShiftLeft.Click += new System.EventHandler(this.btnShiftLeft_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "X1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "X Mag";
            // 
            // btnZoomPlus
            // 
            this.btnZoomPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZoomPlus.Location = new System.Drawing.Point(79, 17);
            this.btnZoomPlus.Name = "btnZoomPlus";
            this.btnZoomPlus.Size = new System.Drawing.Size(23, 24);
            this.btnZoomPlus.TabIndex = 1;
            this.btnZoomPlus.Text = "+";
            this.btnZoomPlus.UseVisualStyleBackColor = true;
            this.btnZoomPlus.Click += new System.EventHandler(this.btnZoomPlus_Click);
            // 
            // btnZoomMinus
            // 
            this.btnZoomMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZoomMinus.Location = new System.Drawing.Point(6, 17);
            this.btnZoomMinus.Name = "btnZoomMinus";
            this.btnZoomMinus.Size = new System.Drawing.Size(23, 24);
            this.btnZoomMinus.TabIndex = 0;
            this.btnZoomMinus.Text = "-";
            this.btnZoomMinus.UseVisualStyleBackColor = true;
            this.btnZoomMinus.Click += new System.EventHandler(this.btnZoomMinus_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1124, 754);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.btnPort);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DSO150 Scope View";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem portToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnPort;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblVSen;
        private System.Windows.Forms.Label lblCouple;
        private System.Windows.Forms.Label lblVMax;
        private System.Windows.Forms.Label lblRecordLength;
        private System.Windows.Forms.Label lblTriggerLevel;
        private System.Windows.Forms.Label lblTriggerSlope;
        private System.Windows.Forms.Label lblTriggerMode;
        private System.Windows.Forms.Label lblHPos;
        private System.Windows.Forms.Label lblTimebase;
        private System.Windows.Forms.Label lblVPos;
        private System.Windows.Forms.Label lblVAvr;
        private System.Windows.Forms.Label lblVMin;
        private System.Windows.Forms.Label lblFrequency;
        private System.Windows.Forms.Label lblVrms;
        private System.Windows.Forms.Label lblVpp;
        private System.Windows.Forms.Label lblDuty;
        private System.Windows.Forms.Label lblPW;
        private System.Windows.Forms.Label lblCycle;
        private System.Windows.Forms.Label lblSampleInterval;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnZoomPlus;
        private System.Windows.Forms.Button btnZoomMinus;
        private System.Windows.Forms.Button btnShiftRight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnShiftLeft;
        private System.Windows.Forms.Label lblEnd;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.Label lblTBase;
    }
}


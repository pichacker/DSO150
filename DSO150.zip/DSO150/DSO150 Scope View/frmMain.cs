﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Timers;

namespace DSO150_Scope_View
{
    public partial class frmMain : Form
    {
        //data variables
        Data_Samples[] DSamples = new Data_Samples[1024];
        string VSen = "----";
        string Couple = "----";
        string VPos = "----";
        string Timebase = "----";
        string HPos = "----";
        string TriggerMode = "----";
        string TriggerSlope = "----";
        string TriggerLevel = "----";
        string RecordLength = "----";
        string Vmax = "----";
        string Vmin = "----";
        string Vavr = "----";
        string Vpp = "----";
        string Vrms = "----";
        string Freq = "----";
        string Cycl = "----";
        string PW = "----";
        string Duty = "----";
        string SampleInterval = "----";

        //screen variables
        int mainFormWidth = 0;
        int mainFormHeight = 0;

        //general program variables
        bool TimerActive = true;
        byte[] RxBufferGlobal = new byte[1024];
        int RxDataCounter = 0;
        int TimerCounter = 0;
        int TimerLoopCounter = 0;
        string WorkingDataFile = "";
        string PortInUse = "";
        public string time = "";
        public string date = "";
        public string file_time = "";
        public string file_date = "";
        int last_plot_point_x = 0;
        int last_plot_point_y = 0;
        int current_plot_point_x = 0;
        int current_plot_point_y = 0;
        int sample_zoom = 1024;
        int sample_start_value = 0;
        int sample_end_value = 1023;
        int sample_mid_point = 512;


        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            Control control = (Control)sender;
            mainFormWidth = this.Width;
            mainFormHeight = this.Height;

            //panel1.Top = groupBox3.Bottom + 10;

            //groupBox1.Width = mainFormWidth - 200;
            //groupBox1.Height = mainFormHeight - 300;


            // Ensure the Form remains square (Height = Width).
            //if (control.Size.Height != control.Size.Width)
            //{
            //    control.Size = new Size(control.Size.Width, control.Size.Width);
            // }

        }


        private void frmMain_Load(object sender, EventArgs e)
        {
            mainFormWidth = this.Width;
            mainFormHeight = this.Height;
            label2.Text = (1024 / sample_zoom).ToString();

            string[] ports = SerialPort.GetPortNames();

            CheckForIllegalCrossThreadCalls = false;    //It helps us to update richedittextbox1 content in the serial port datareceived event. Otherwise program will generate error
            serialPort1.ReadTimeout = 1000;             //1 Seconds

            //Get available COM ports and populate the menu list accordingly
            foreach (string port_name in ports)
            {
                ToolStripItem item = new ToolStripMenuItem();
                item.Text = port_name;//Name that will apear on the menu
                item.Name = port_name;//Put in the Name property whatever neccessery to retrive your data on click event
                item.Click += new EventHandler(Com_Item_Click);//On-Click event
                settingToolStripMenuItem.DropDownItems.Add(item); //Add the submenu to the parent menu
            }

            try
            {
                PortInUse = Properties.Settings.Default.PortName;
                statusStrip1.Items[1].Text = "";
                statusStrip1.Items[0].Text = PortInUse;
            }
            catch
            {
                statusStrip1.Items[1].Text = "No available COM ports to use";
            }

            this.timer1.Interval = 100;
            timer1.Start();
            this.timer2.Interval = 200;
            timer2.Start();

            lblStart.Text = "0";
            lblEnd.Text = "1023";

            TimerActive = false;
            load_data_sumary();
            draw_graticule();

        }

        void Com_Item_Click(object sender, EventArgs e)
        {
            PortInUse = sender.ToString();
            Properties.Settings.Default.PortName = PortInUse;
            Properties.Settings.Default.Save();
            statusStrip1.Items[0].Text = PortInUse;
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int RxCounter = 0;
            int ArraySize = 0;

            statusStrip1.Items[1].Text = "Receiving Data";

            try
            {
                ArraySize = RxBufferGlobal.Length;
                if (ArraySize > 1000)
                {
                    Array.Resize(ref RxBufferGlobal, 1000);
                    RxBufferGlobal.Initialize();
                    RxDataCounter = 0;
                }

            HERE:
                RxCounter = RxDataCounter;

                ArraySize = RxBufferGlobal.Length;

                if (RxCounter == ArraySize)
                {
                    Array.Resize(ref RxBufferGlobal, (RxCounter + 1));
                }

                RxBufferGlobal[RxDataCounter] = (byte)serialPort1.ReadByte();
                RxDataCounter++;
                if (RxDataCounter != RxCounter)
                {
                    goto HERE;
                }

            }
            catch
            {
                if ((RxDataCounter < 29900) || (RxDataCounter > 32000))
                {
                    statusStrip1.Items[1].Text = "Incomplete Data Received";
                }
                else
                {
                    statusStrip1.Items[1].Text = "Data Received OK";
                    convert_databuffer_to_string();
                    try
                    {
                        process_loaded_data_file();     //process the loaded file data
                        load_data_sumary();             //update summary display
                    }
                    catch
                    {
                    }

                }
            }

            EnableTimer(50);
            return;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //must close port if open
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception ex)
                {
                    statusStrip1.Items[1].Text = ex.Message.ToString();
                    return;
                }
            }
            Application.Exit();
        }

        private void btnReadDSO_Click(object sender, EventArgs e)
        {
            RxBufferGlobal.Initialize();
            RxDataCounter = 0;
        }

        void convert_databuffer_to_string()
        {
            int RxLength = 0;
            int i = 0;

            RxLength = RxDataCounter;
            //statusStrip1.Items[1].Text = RxLength.ToString();

            WorkingDataFile = "";
            try
            {
                for (i = 0; i < RxLength; i++)
                {
                    string stringValue = Char.ConvertFromUtf32(RxBufferGlobal[i]);
                    WorkingDataFile = WorkingDataFile + stringValue;
                }
            }
            catch
            {
            }
            return;
        }

        #region Timer Stuff
        void EnableTimer(int TimeVal)
        {
            TimerCounter = 0;
            TimerCounter = TimeVal;
            TimerActive = true;
            return;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (TimerActive == true)
            {
                TimerLoopCounter++;
                if (TimerLoopCounter > TimerCounter)
                {
                    TimerLoopCounter = 0;
                    TimerActive = false;
                    statusStrip1.Items[1].Text = "";
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            draw_graticule();
            timer2.Stop();
        }

        #endregion

        #region File Loading And Saving

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
            {
                serialPort1.PortName = PortInUse;
                serialPort1.BaudRate = 115200;
                try
                {
                    serialPort1.Open();
                }
                catch (Exception ex)
                {
                    statusStrip1.Items[0].Text = ex.Message.ToString();
                    EnableTimer(50);
                    return;
                }
                statusStrip1.Items[0].Text = serialPort1.PortName.ToString() + " Open";
                //statusStrip1.Items[1].Text = serialPort1.PortName.ToString() + " is opened at " + serialPort1.BaudRate.ToString() + " bps";
            }
            else
            {
                statusStrip1.Items[1].Text = "Port has aready been opened";
            }
            btnPort.Text = "Close Port";
            EnableTimer(20);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception ex)
                {
                    statusStrip1.Items[1].Text = ex.Message.ToString();
                    EnableTimer(50);
                    return;
                }

                statusStrip1.Items[0].Text = serialPort1.PortName.ToString() + " Closed";
            }
            else
            {
                statusStrip1.Items[1].Text = "Port has aready been closed";
            }
            btnPort.Text = "Open Port";
            EnableTimer(20);

        }

        private void btnPort_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception ex)
                {
                    statusStrip1.Items[1].Text = ex.Message.ToString();
                    EnableTimer(50);
                }

                statusStrip1.Items[0].Text = serialPort1.PortName.ToString() + " Closed";
                btnPort.Text = "Open Port";
            }
            else
            {
                serialPort1.PortName = PortInUse;
                serialPort1.BaudRate = 115200;
                try
                {
                    serialPort1.Open();
                }
                catch (Exception ex)
                {
                    statusStrip1.Items[0].Text = ex.Message.ToString();
                    EnableTimer(50);
                }
                statusStrip1.Items[0].Text = serialPort1.PortName.ToString() + " Open";
                btnPort.Text = "Close Port";
            }
            EnableTimer(20);
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.ShowDialog();
            }
            catch
            {
            }

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                file_time = DateTime.Now.ToString("HHmm"); // includes leading zeros
                file_date = DateTime.Now.ToString("yyyyMMdd"); // includes leading zeros

                string SaveFileName = "DSO150_" + file_date + "_" + file_time;

                saveFileDialog1.Filter = "Text File | *.txt";
                saveFileDialog1.FileName = SaveFileName;
                saveFileDialog1.ShowDialog();
            }
            catch
            {
            }

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                string name = saveFileDialog1.FileName;
                File.WriteAllText(name, WorkingDataFile);
            }
            catch
            {
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string text = System.IO.File.ReadAllText(openFileDialog1.FileName);
            WorkingDataFile = text;
            try
            {
                process_loaded_data_file();     //process the loaded file data
                load_data_sumary();             //update summary display
                sample_zoom = 1024;
                label2.Text = (1024 / sample_zoom).ToString();
                draw_graticule();
            }
            catch
            {
            }
        }

        #endregion

        void load_data_sumary()
        {
            //input
            lblCouple.Text = ("Couple".PadRight(8, ' ')) + " " + Couple.Replace(" ", "");
            lblVSen.Text = ("Vsen".PadRight(9, ' ')) + " " + VSen.Replace(" ", "");
            lblVPos.Text = ("Vpos".PadRight(9, ' ')) + " " + VPos.Replace(" ", "");
            lblHPos.Text = ("Hpos".PadRight(9, ' ')) + " " + HPos.Replace(" ", "");

            //sweep
            lblTimebase.Text = "Timebase".PadRight(17, ' ') + " " + Timebase.Replace(" ", "");
            lblTriggerMode.Text = "Trigger Mode".PadRight(15, ' ') + " " + TriggerMode.Replace(" ", "");
            lblTriggerLevel.Text = "Trigger Level".PadRight(16, ' ') + " " + TriggerLevel.Replace(" ", "");
            lblTriggerSlope.Text = "Trigger Slope".PadRight(16, ' ') + " " + TriggerSlope.Replace(" ", "");

            //statistics
            lblFrequency.Text = "Frequency".PadRight(12, ' ') + " " + Freq.Replace(" ", "");
            lblCycle.Text = "Cycle".PadRight(16, ' ') + " " + Cycl.Replace(" ", "");
            lblPW.Text = "PW".PadRight(16, ' ') + " " + PW.Replace(" ", "");
            lblDuty.Text = "Duty".PadRight(16, ' ') + " " + Duty.Replace(" ", "");

            lblRecordLength.Text = "Record Length".PadRight(16, ' ') + " " + RecordLength.Replace(" ", "");
            lblSampleInterval.Text = "Sample Interval".PadRight(17, ' ') + " " + SampleInterval.Replace(" ", "");
            lblVMax.Text = "Vmax".PadRight(22, ' ') + " " + Vmax.Replace(" ", "");
            lblVMin.Text = "Vmin".PadRight(23, ' ') + " " + Vmin.Replace(" ", "");

            lblVpp.Text = "Vpp".PadRight(8, ' ') + " " + Vpp.Replace(" ", "");
            lblVAvr.Text = "Vavr".PadRight(8, ' ') + " " + Vavr.Replace(" ", "");
            lblVrms.Text = "Vrms".PadRight(8, ' ') + " " + Vrms.Replace(" ", "");

            return;
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            process_loaded_data_file();     //process the loaded file data
            load_data_sumary();             //update summary display
            draw_graticule();
        }

        void process_loaded_data_file()
        {
            int Sample_Number = 0;
            DSamples.Initialize();

            using (StringReader reader = new StringReader(WorkingDataFile))
            {
                string line = string.Empty;
                do
                {
                    line = reader.ReadLine();
                    if (line != null)
                    {
                        if (line.Contains("VSen")) { VSen = line.Replace("VSen,", ""); }
                        if (line.Contains("Couple")) { Couple = line.Replace("Couple,", ""); }
                        if (line.Contains("VPos")) { VPos = line.Replace("VPos,", ""); }
                        if (line.Contains("Timebase")) { Timebase = line.Replace("Timebase,", ""); }
                        if (line.Contains("HPos")) { HPos = line.Replace("HPos,", ""); }
                        if (line.Contains("TriggerMode")) { TriggerMode = line.Replace("TriggerMode,", ""); }
                        if (line.Contains("TriggerSlope")) { TriggerSlope = line.Replace("TriggerSlope,", ""); }
                        if (line.Contains("TriggerLevel")) { TriggerLevel = line.Replace("TriggerLevel,", ""); }
                        if (line.Contains("RecordLength")) { RecordLength = line.Replace("RecordLength,", ""); }
                        if (line.Contains("Vmax")) { Vmax = line.Replace("Vmax,", ""); }
                        if (line.Contains("Vmin")) { Vmin = line.Replace("Vmin,", ""); }
                        if (line.Contains("Vavr")) { Vavr = line.Replace("Vavr,", ""); }
                        if (line.Contains("Vpp")) { Vpp = line.Replace("Vpp,", ""); }
                        if (line.Contains("Vrms")) { Vrms = line.Replace("Vrms,", ""); }
                        if (line.Contains("Freq")) { Freq = line.Replace("Freq,", ""); }
                        if (line.Contains("Cycl")) { Cycl = line.Replace("Cycl,", ""); }
                        if (line.Contains("PW")) { PW = line.Replace("PW,", ""); }
                        if (line.Contains("Duty")) { Duty = line.Replace("Duty,", ""); }
                        if (line.Contains("SampleInterval")) { SampleInterval = line.Replace("SampleInterval,", ""); }

                        try
                        {
                            //tempstring = line.Substring(0, 1);
                            if (line.Substring(0, 1) == "0")
                            {
                                Sample_Number = Convert.ToInt16(line.Substring(0, 5));
                                DSamples[Sample_Number] = new Data_Samples
                                {
                                    Sample_Value = float.Parse(line.Substring(17, 10)),
                                    Sample_Timing = Convert.ToInt32(line.Substring(6, 10))
                                };
                            }
                        }
                        catch
                        {
                        }
                    }
                } while (line != null);
            }
        }

        void draw_graticule()
        {
            int DispWidth = 0;
            int DispHeight = 0;
            int x = 0;
            int y = 0;
            int z = 0;

            //this.panel1.Dispose();

            Graphics gObject = panel1.CreateGraphics();

            panel1.Refresh();

            Brush green = new SolidBrush(Color.Green);
            Brush red = new SolidBrush(Color.Red);
            Brush black = new SolidBrush(Color.Black);
            Brush white = new SolidBrush(Color.White);
            Brush gray = new SolidBrush(Color.Gray);

            Pen greenPen = new Pen(green, 2);
            Pen redPen = new Pen(red, 2);
            Pen blackPen = new Pen(black, 1);

            Pen thinGrayPen = new Pen(gray, 1);

            Pen thinWhitePen = new Pen(white, 1);
            Pen mediumWhitePen = new Pen(white, 3);
            Pen thickWhitePen = new Pen(white, 5);

            DispHeight = panel1.Height;
            DispWidth = panel1.Width;

            //draw grid
            for (x = 0; x < 9; x++)
            {
                gObject.DrawLine(thinGrayPen, 0, x * (DispHeight / 8), DispWidth, x * (DispHeight / 8));

                //draw cross hairs
                y = (x * (DispHeight / 8));
                for (z = 0; z < 5; z++)
                {
                    gObject.DrawLine(thinGrayPen, (DispWidth / 2) - 5, (y + (z * 14)), (DispWidth / 2) + 4, (y + (z * 14)));
                }
            }

            for (y = 0; y < 13; y++)
            {
                gObject.DrawLine(thinGrayPen, y * (DispWidth / 12), 0, y * (DispWidth / 12), DispHeight);

                //draw cross hairs
                x = (y * (DispWidth / 12));
                for (z = 0; z < 5; z++)
                {
                    gObject.DrawLine(thinGrayPen, (x + (z * 18)), (DispHeight / 2) - 5, (x + (z * 18)), (DispHeight / 2) + 5);
                }


            }

            //draw boarder
            gObject.DrawLine(thickWhitePen, 0, 0, DispWidth - 5, 0);
            gObject.DrawLine(thickWhitePen, 0, 0, 0, DispHeight - 5);
            gObject.DrawLine(thickWhitePen, 0, DispHeight - 5, DispWidth - 5, DispHeight - 5);
            gObject.DrawLine(thickWhitePen, DispWidth - 5, 0, DispWidth - 5, DispHeight - 5);

            //lblHeight.Text = "height " + DispHeight.ToString();
            //lblWidth.Text = "width " + DispWidth.ToString();

            try
            {
                VSen = VSen.Replace("----", "0");
                VSen = VSen.Replace("V", "");
                float Vsens = float.Parse(VSen);


                if (sample_start_value > (sample_end_value - 32))
                {
                    sample_start_value = (sample_end_value - 32);
                }
                
                //sample_start_value = 0;

                sample_end_value = sample_start_value + sample_zoom;

                if (sample_end_value > 1023)
                { sample_end_value = 1023; 
                }

                sample_mid_point =  ((sample_end_value - sample_start_value)/2) + sample_start_value;

                plot_trace(Vsens, sample_start_value,sample_end_value);

                lblStart.Text = sample_start_value.ToString();
                lblEnd.Text = sample_end_value.ToString();
                lblTBase.Text = (1024/sample_zoom).ToString();
                lblTBase.Text = convert_timebase();

            }
            catch
            {
            }

        }

        string convert_timebase()
        {
            string TimeBaseString = "";
            string TimeBaseScreen = "";
            float TB_Sec=0F;
            
            TimeBaseString = Timebase.Replace(" ", "");
            switch (TimeBaseString)
            {
                case "500s": { TB_Sec = 500; break; }
                case "200s": { TB_Sec = 200; break; }
                case "100s": { TB_Sec = 100; break; }

                case "50s": { TB_Sec = 50; break; }
                case "20s": { TB_Sec = 20; break; }
                case "10s": { TB_Sec = 10; break; }

                case "5s": { TB_Sec = 5; break; }
                case "2s": { TB_Sec = 2; break; }
                case "1s": { TB_Sec = 1; break; }

                case "0.5s": { TB_Sec = 0.5F; break; }
                case "0.2s": { TB_Sec = 0.2F; break; }
                case "0.1s": { TB_Sec = 0.1F; break; }

                case "50ms": { TB_Sec = 0.05F; break; }
                case "20ms": { TB_Sec = 0.02F; break; }
                case "10ms": { TB_Sec = 0.01F; break; }

                case "5ms": { TB_Sec = 0.005F; break; }
                case "2ms": { TB_Sec = 0.002F; break; }
                case "1ms": { TB_Sec = 0.001F; break; }

                case "0.5ms": { TB_Sec = 0.0005F; break; }
                case "0.2ms": { TB_Sec = 0.0002F; break; }
                case "0.1ms": { TB_Sec = 0.0001F; break; }

                case "50us": { TB_Sec = 0.00005F; break; }
                case "20us": { TB_Sec = 0.00002F; break; }
                case "10us": { TB_Sec = 0.00001F; break; }
            }

            float CalcTB = (TB_Sec / (1024 / sample_zoom));

            if (CalcTB >= 1.0)
            {
             TimeBaseScreen = CalcTB.ToString() + " s/div";
             goto DONE;
            }

            if ((CalcTB < 1.0) & (CalcTB >= 0.001))
            {
                TimeBaseScreen = (CalcTB * 1000).ToString() + " ms/div";
                goto DONE;
            }

            if ((CalcTB < 0.001))
            {
                TimeBaseScreen = (CalcTB * 1000000).ToString() + " us/div";
                goto DONE;
            }
            
            DONE:
            return (TimeBaseScreen);
        }

        void plot_trace(double Vsen_Local, int Start_Sample, int End_Sample)
        {
            int DispWidth = 0;
            int DispHeight = 0;
            int z = 0;
            float Xpos = 0;
            float Ypos = 0;
            float Ypos_value = 0;
            float Vpos_value =0;

            
            Graphics gObject = this.panel1.CreateGraphics();
            //Bitmap bm = new Bitmap(1, 1);  
            //bm.SetPixel(0, 0, Color.Yellow); 
            //gObject.DrawImageUnscaled(bm, 15, 15);
           

            Brush yellow = new SolidBrush(Color.Yellow);
            Pen yellowPen = new Pen(yellow, 1);

            DispHeight = panel1.Height;
            DispWidth = panel1.Width;

            int number_of_samples = End_Sample - Start_Sample;
            float sample_points = (float)DispWidth / (float)number_of_samples;
            float samples_per_division = (float)((DispHeight / 2) / 4);

            last_plot_point_x = 0;
            last_plot_point_y = 0;


            for (z = 0; z < number_of_samples; z++)
            {
                Xpos = z * sample_points;
                try
                {
                    Ypos_value = DSamples[Start_Sample + z].Sample_Value;
                    Vpos_value = float.Parse(VPos.Replace("V",""));
                    Ypos_value = Ypos_value + Vpos_value;
                    float scaler = (Ypos_value)   / (float)Vsen_Local;
                   
                    Ypos = (samples_per_division * scaler) + (DispHeight/2);
                    Ypos = DispHeight - Ypos;

                }
                catch
                {
                    return; //array not loaded yet
                }
                
                current_plot_point_x = (int)Xpos;
                current_plot_point_y = (int)Ypos;

                if (last_plot_point_x == 0)   { last_plot_point_x = current_plot_point_x; }
                if (last_plot_point_y == 0)   { last_plot_point_y= current_plot_point_y; }

                gObject.DrawLine(yellowPen, last_plot_point_x, last_plot_point_y, current_plot_point_x, current_plot_point_y);

                last_plot_point_x = current_plot_point_x;
                last_plot_point_y = current_plot_point_y;

            }



        
        
        }

        private void btnZoomMinus_Click(object sender, EventArgs e)
        {
            int sample_mid_temp = 0;
            sample_mid_temp = ((sample_end_value - sample_start_value) / 2) + sample_start_value;
            
            switch (sample_zoom)
            {
                case 512: { sample_zoom = 1024; break; }
                case 256: { sample_zoom = 512; break; }
                case 128: { sample_zoom = 256; break; }
                case 64: { sample_zoom = 128; break; }
                case 32: { sample_zoom = 64; break; }
            }

            sample_start_value = sample_mid_temp - (sample_zoom/2);
            if (sample_start_value < 1)
            {
                sample_start_value = 0;
            }

            label2.Text = (1024 / sample_zoom).ToString();
            draw_graticule();
        }

        private void btnZoomPlus_Click(object sender, EventArgs e)
        {
            int sample_mid_temp = 0;
            sample_mid_temp = ((sample_end_value - sample_start_value) / 2) + sample_start_value;

            switch (sample_zoom)
            {
                case 1024: { sample_zoom = 512; break; }
                case 512: { sample_zoom = 256; break; }
                case 256: { sample_zoom = 128; break; }
                case 128: { sample_zoom = 64; break; }
                case 64: { sample_zoom = 32; break; }
            }

            sample_start_value = sample_mid_temp - (sample_zoom / 2);
            if (sample_start_value < 1)
            {
                sample_start_value = 0;
            }
            
            label2.Text = (1024 / sample_zoom).ToString();
            draw_graticule();
        }

        private void btnShiftLeft_Click(object sender, EventArgs e)
        {
            int sample_percentage = 0;
            int number_of_samples = 0;

            number_of_samples = sample_end_value - sample_start_value;
            sample_percentage = (number_of_samples / 100) * 2;

            if (sample_start_value < (1023 - sample_percentage))
            {
                sample_start_value = sample_start_value + sample_percentage;
                sample_end_value = sample_start_value + number_of_samples;
                if (sample_end_value > 1023)
                { sample_start_value = 0; 
                }

                draw_graticule();
            }
        }

        private void btnShiftRight_Click(object sender, EventArgs e)
        {
            int sample_percentage = 0;
            int number_of_samples = 0;

            number_of_samples = sample_end_value - sample_start_value;
            sample_percentage = (number_of_samples / 100) * 2;

            if (sample_start_value > sample_percentage)
            {
                sample_start_value = sample_start_value - sample_percentage;
                draw_graticule();
            }
        }
    
    }

    public class Data_Samples
    {
        public float Sample_Value;
        public int Sample_Timing;
    }

}
